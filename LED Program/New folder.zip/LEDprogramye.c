void main()
{
     int a=0;
     int x=0;
     TRISB=0b00000000;


          while(1)
     {
          //First 4
    PORTB.F7=0;
         PORTB.F0=1;
         PORTB.F1=0;
         PORTB.F2=0;
         PORTB.F3=0;
                 PORTB.F4=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F4=0;
                 PORTB.F5=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F5=0;
                 PORTB.F6=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F6=0;
                 PORTB.F7=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F7=0;

          //Second 4
          PORTB.F7=0;
         PORTB.F0=0;
         PORTB.F1=1;
         PORTB.F2=0;
         PORTB.F3=0;
                 PORTB.F4=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F4=0;
                 PORTB.F5=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F5=0;
                 PORTB.F6=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F6=0;
                 PORTB.F7=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }


                 //Third 4
    PORTB.F7=0;
         PORTB.F0=0;
         PORTB.F1=0;
         PORTB.F2=1;
         PORTB.F3=0;
                 PORTB.F4=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F4=0;
                 PORTB.F5=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F5=0;
                 PORTB.F6=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F6=0;
                 PORTB.F7=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F7=0;

          //Fourth 4
          PORTB.F7=0;
         PORTB.F0=0;
         PORTB.F1=0;
         PORTB.F2=0;
         PORTB.F3=1;
                 PORTB.F4=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F4=0;
                 PORTB.F5=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F5=0;
                 PORTB.F6=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }

                 PORTB.F6=0;
                 PORTB.F7=1;
                 //delay
                 a=0;
                 while(a<50000)
                 {
                     a=a+1;
                 }


     }





}